# Chat_Bot_Group_Case_Study

Notes:
1. Below mentioned validation as stated wasn't clear if the validation should be only location or location + Cuisine. Hence we are allowing showing of restauarnts even if
less than 5 were identified with a message saying "Sorry! less than 5 restaurants were found"

If the location doesn't have 5 restaurants, then the bot should not provide any result for that area.

2. Cusine preference: We are allowing to search only for below applicable Cusine
    Chinese
    Mexican
    Italian
    American
    South Indian
    North Indian
    
3. Contents of req.txt is populated with outcome of "pip freeze" command
 
