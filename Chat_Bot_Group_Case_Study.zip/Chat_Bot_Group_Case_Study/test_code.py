import pandas as pd
import json


ZomatoData = pd.read_csv('zomato.csv')
ZomatoData = ZomatoData.drop_duplicates().reset_index(drop=True)
WeOperate = ['New Delhi', 'Gurgaon', 'Noida', 'Faridabad', 'Allahabad', 'Bhubaneshwar', 'Mangalore', 'Mumbai', 'Ranchi', 'Patna', 'Mysore', 'Aurangabad', 'Amritsar', 'Puducherry', 'Varanasi', 'Nagpur', 'Vadodara', 'Dehradun', 'Vizag', 'Agra', 'Ludhiana', 'Kanpur', 'Lucknow', 'Surat', 'Kochi', 'Indore', 'Ahmedabad', 'Coimbatore', 'Chennai', 'Guwahati', 'Jaipur', 'Hyderabad', 'Bangalore', 'Nashik', 'Pune', 'Kolkata', 'Bhopal', 'Goa', 'Chandigarh', 'Ghaziabad', 'Ooty', 'Gangtok', 'Shimla']

def RestaurantSearch(City,Cuisine):
    TEMP = ZomatoData[(ZomatoData['Cuisines'].apply(lambda x: Cuisine.lower() in x.lower())) & (ZomatoData['City'].apply(lambda x: City.lower() in x.lower()))]
    return TEMP[['Restaurant Name','Address','Average Cost for two','Aggregate rating']]

# class ActionSearchRestaurants():
#     def name(self):
#         #return 'action_search_restaurants'
def test_run(location,cuis,price):
    count = 0
    loc = location
    cuisine = cuis
    budget = price
    results = RestaurantSearch(City=loc,Cuisine=cuisine)
    response=""
        
    # defalut budget range set to high
    #budget_range = "high" 
        
    # Set the budget scale 
    if budget == "299":
        budget_range = "low"
    elif budget == "700":
        budget_range = "mod"
    elif budget == "701":
        budget_range = "high"
    else:
        budget_range = "low"
        
        
    # Below condition to validate for locations where operations does not exist
    if loc.lower() not in (string.lower() for string in WeOperate):
        response= "Sorry we don't operate in " + loc + " area yet."
        print("-----"+response)
        
    # Below condition to validate, If the location doesn't have 5 restaurants, then the bot should not provide any result for that area.
    #elif results.shape[0] < 5:
    #    response= "Sorry! We don't have matching restaurants for " + loc + " location and " +cuisine + " Cusine."
    else:
        # Sort results dataframe in decending order of Aggregate rating and ascending order of restaurant name.
        results = results.sort_values(["Aggregate rating", "Restaurant Name"], ascending = (False, True))            
        # Itereate through top 5 results
        for restaurant in results.iterrows():
            restaurant = restaurant[1]
            if((budget_range == "low") and (restaurant['Average Cost for two'] < 300) and (count <= 5)):
                response=response + F"Found {count} {budget_range} {restaurant['Restaurant Name']} in {restaurant['Address']} rated {restaurant['Aggregate rating']} with avg cost {restaurant['Average Cost for two']} \n\n" 
                count = count + 1
            elif((budget_range == "mod") and (restaurant['Average Cost for two']  >= 300) and (restaurant['Average Cost for two'] <= 700) and (count <= 5)):
                response=response + F"Found {count} {budget_range}{restaurant['Restaurant Name']} in {restaurant['Address']} rated {restaurant['Aggregate rating']} with avg cost {restaurant['Average Cost for two']} \n\n" 
                count = count + 1
            elif((budget_range == "high") and (restaurant['Average Cost for two']  > 700) and (count <= 5)):
                response=response + F"Found {count} {budget_range} {restaurant['Restaurant Name']} in {restaurant['Address']} rated {restaurant['Aggregate rating']} with avg cost {restaurant['Average Cost for two']} \n\n" 
                count = count + 1
            if(count==5):
                print(response)
                break
    if(count<5 and count>0):
        response=response + "Sorry! less than 5 restaurnts found"
        print(response)                    
    elif(count==0):
        response = "Sorry, No results found for your criteria. Would you like to search for some other restaurants?"
        print(response)                
              
    # return [SlotSet('emailbody',response)]
    
test_run("rishikesh","chinese","299")
    
# class ActionSendMail(Action):
#     def name(self):
#         return 'action_send_mail'

#     # def run(self, dispatcher, tracker, domain):
#     #     MailID = tracker.get_slot('mail_id')
#     #     sendmail(MailID,response)
#     #     return [SlotSet('mail_id',MailID)]


#     def run(self, dispatcher, tracker, domain):
#         from_user = 'chatbot2021.upgrad@gmail.com'
#         to_user = tracker.get_slot('email')
#         body = tracker.get_slot('emailbody')
#         password = 'Chatbot2021*'
#         server = smtplib.SMTP('smtp.gmail.com',587)
#         server.starttls()
#         server.login(from_user, password)
#         subject = 'Foodie ChatBot: Your requested list if restaurants'
#         msg = MIMEMultipart()
#         msg['From'] = from_user
#         msg['TO'] = to_user
#         msg['Subject'] = subject
#         msg.attach(MIMEText(body,'plain'))
#         text = msg.as_string()
#         server.sendmail(from_user,to_user,text)
#         server.close()    
   
    
